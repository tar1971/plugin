
#!/bin/sh
#

wget https://raw.githubusercontent.com/tarekzoka/NitroAdvanceFHD/main/tarek.sh -O - | /bin/sh