wait


wget "https://raw.githubusercontent.com/tarekzoka/SKINS/main/Skin%20NitroGreenWoodFHD.tar.gz"


tar -xzf Skin%20NitroGreenWoodFHD.tar.gz  -C /

wait
rm -f /tmp/Skin%20NitroGreenWoodFHD.tar.gz
echo "   UPLOADED BY  >>>>   TAREK_TT "   
sleep 4;                                                                                                                  
echo ". >>>>         RESTARING     <<<<"
echo "**********************************************************************************"
wait
killall -9 enigma2
exit 0
