echo

opkg install --force-overwrite  https://drive.google.com/uc?id=1zx7-uLTTM1v-4xoUxL3p7SDqMIR6nyNP&export=download
wait
sleep 2;
killall -9 enigma2
exit 0





