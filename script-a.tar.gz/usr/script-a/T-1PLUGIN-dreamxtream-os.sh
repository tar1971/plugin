
#!/bin/sh
#

wget https://raw.githubusercontent.com/tarekzoka/68/main/installer.sh -O - | /bin/sh