#!/bin/bash
wget https://raw.githubusercontent.com/tarekzoka/ts-sateditor/main/installer3.sh -O - | /bin/sh















