echo
opkg install --force-overwrite  https://github.com/tarekzoka/plugins/blob/main/SKIN-ORANGESKY-P-FHD-By-Muaath.ipk?raw=true
wait
sleep 2;
exit 0





