echo
opkg install --force-overwrite  https://drive.google.com/uc?id=1snj28tROS1R3vYtzpWnhGslNmgqz5anc&export=download
wait
sleep 2;
exit 0





