wait

opkg install --force-overwrite  https://drive.google.com/uc?id=1B9dg67KXpJd2o2NocHrK-IG1Ut2Sv6jE&export=download
wait
sleep 2;
exit 0


