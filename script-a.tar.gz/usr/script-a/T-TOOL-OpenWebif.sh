opkg remove enigma2-plugin-extensions-OpenWebif owait
sleep 2;
opkg install --force-overwrite https://drive.google.com/uc?id=1-p-gIbnKviC5asc-jPvJPASEedu2gaNY&export=download
wait
sleep 2;
exit 0


