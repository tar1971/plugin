#!/bin/sh
echo "Uninstall"
sleep 1
echo "etc-enigma2-lamedb "
opkg remove etc-enigma2-lamedb 
rm -rf /etc-enigma2-lamedb /
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
echo "OK"
wait

opkg install --force-overwrite "https://drive.google.com/uc?id=1vYbl3Xk4Ft8bwgQpSo5rhGosF7vKnT1C&export=download"

wait
sleep 2;
exit 0



