wget -q "--no-check-certificate" http://ipkinstall.ath.cx/ipk-install/PY3/AlternativeSoftCamManager/installer.sh -O - | /bin/sh
