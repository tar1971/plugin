
opkg install --force-overwrite  https://drive.google.com/uc?id=1yKRcLjhIBGc7fC-fmbA6PirZO3oA4fji&export=download
wait
sleep 2;
exit 0


