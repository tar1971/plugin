#!/bin/sh
 # 
echo
# script download my scripts #  
cd /tmp
set -e 
wget -O /tmp/script-a.tar.gz "https://onedrive.live.com/download?cid=CFCA224FBA296C58&resid=CFCA224FBA296C58%21171&authkey=AK2ZPuDOG-Zv7e8" > /tmp/script-a.tar.gz
sleep 1
wait
tar -xzf script-a.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/script-a.tar.gz
echo "   UPLOADED BY  >>>>   TAR_TAR "   
sleep 4;                                                                                                                  
echo ". >>>>         RESTARING     <<<<"
echo "**********************************************************************************"
wait
killall -9 enigma2
exit 0


