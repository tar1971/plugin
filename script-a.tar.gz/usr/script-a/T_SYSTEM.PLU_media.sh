opkg update 
opkg remove enigma2-plugin-extensions-serviceapp exteplayer3 ffmpeg 
opkg install ffmpeg exteplayer3 enigma2-plugin-extensions-serviceapp

wait
opkg install gstplayer
wait
opkg install ffmpeg exteplayer3 enigma2-plugin-systemplugins-serviceapp
wait
sleep 2;
exit 0
