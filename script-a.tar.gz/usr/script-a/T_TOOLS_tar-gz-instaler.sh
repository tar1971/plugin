tar xzvpf /tmp/*.tar.gz  -C /
wait
sleep 2;
exit 0
