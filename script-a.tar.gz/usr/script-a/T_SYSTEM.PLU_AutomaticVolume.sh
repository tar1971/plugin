
wait
sleep 2;
opkg install --force-overwrite  https://drive.google.com/uc?id=1e894TKBdAUTgXXouFUa_hkGtVoZ4jt0B&export=download
wait
sleep 2;
exit 0








