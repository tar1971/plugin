opkg install --force-overwrite  http://178.63.156.75/paneladdons/skins/OpenATV/skin-octelfhd_2.2-By-SkinMania-MOD-By-MEHDI_all.ipk
wait
sleep 2;
exit 0
