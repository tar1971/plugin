#!/bin/sh
 # 
 # # 
cd /tmp
set -e 
wget "https://github.com/tarekzoka/SKINS/blob/main/enigma2-plugin_1.1.1-skin.BO-HLALA.OpenBH.Xevnt1.FHD.tar.gz?raw=truez"
wait
tar -xzf plugin_1.1.1-skin.BO-HLALA.OpenBH.Xevnt1.FHD.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/plugin_1.1.1-skin.BO-HLALA.OpenBH.Xevnt1.FHD.tar.gz
echo "   UPLOADED BY  >>>>   TAR_TAR "   
sleep 4;                                                                                                                  
echo ". >>>>         RESTARING     <<<<"
echo "**********************************************************************************"
wait
killall -9 enigma2
exit 0



















