wait

wget "https://raw.githubusercontent.com/tarekzoka/SKINS/main/skin-NAGA%20CLBS-FHD.tar.gz"

tar -xzf skin-NAGA%20CLBS-FHD.tar.gz  -C /

wait

rm -f /tmp/skin-NAGA%20CLBS-FHD.tar.gz

echo "   UPLOADED BY  >>>>   TAREK_TT "   
sleep 4;                                                                                                                  
echo ". >>>>         RESTARING     <<<<"
echo "**********************************************************************************"
wait
killall -9 enigma2
exit 0

https://github.com/tarekzoka/SKINS/blob/main/skin-NAGA%20CLBS-FHD.tar.gz