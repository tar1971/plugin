rm -r /usr/lib/enigma2/python/Plugins/Extensions/IPAudio

