
wget http://tunisia-dreambox.info/TSplugins/RaedQuickSignal/installer.sh  -O - | /bin/sh
wait
sleep 2;
exit 0
