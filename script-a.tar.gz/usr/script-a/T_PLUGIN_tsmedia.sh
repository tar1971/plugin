
wget http://tunisia-dreambox.info/TSmedia/software_official/installer.sh -O - | /bin/sh 
wait
sleep 2;
exit 0
