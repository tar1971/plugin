wait


wget "https://raw.githubusercontent.com/tarekzoka/CHANNELL/main/CHANNEL-TAREKALASHRY.tar.gz"


tar -xzf CHANNEL-TAREKALASHRY.tar.gz  -C /

wait
rm -f /tmp/CHANNEL-TAREKALASHRY.tar.gz
echo "   UPLOADED BY  >>>>   TAREK_TT "   
sleep 4;                                                                                                                  
echo ". >>>>         RESTARING     <<<<"
echo "**********************************************************************************"
wait
killall -9 enigma2
exit 0
