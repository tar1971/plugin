
#!/bin/sh
#

wget -O /tmp/skin-hdsuisse.fhd_merlin_7.1.tar.gz "https://drive.google.com/uc?id=1S4Ib43IZCZiY7joEptdeWRhtMpiEp6dZ&export=download"

tar -xzf /tmp/*.tar.gz -C /


wait

killall -9 enigma2

sleep 2;

exit 0
