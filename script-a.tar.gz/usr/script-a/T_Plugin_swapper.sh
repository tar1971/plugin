
#!/bin/sh
#

wget -O /tmp/swapper-nature3.tar.gz "https://drive.google.com/uc?id=14Jj8DHbTbO-jxum1NpLxqRxz40VgjPro&export=download"

tar -xzf /tmp/*.tar.gz -C /

rm -r /tmp/swapper-nature3.tar.gz

killall -9 enigma2

sleep 2;

exit 0
swapper-nature3.tar