#!/bin/sh
echo "Uninstall"
sleep 1
echo "odinstalace pluginu e2iplayer"
opkg remove enigma2-plugin-extensions-e2iplayer
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/IPTVPlayer/
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
echo "OK"
exit
