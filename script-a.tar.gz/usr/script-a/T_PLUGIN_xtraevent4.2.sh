echo
opkg install --force-overwrite  "https://github.com/tarekzoka/NitroAdvanceFHD/blob/main/enigma2-plugin-extensions-xtraevent_v4.2_all.ipk?raw=true"
wait
sleep 2;
exit 0

































