wait
wget https://raw.githubusercontent.com/tarekzoka/LinuxCommands/main/installer.sh -O - | /bin/sh



