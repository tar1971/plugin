wait
opkg install --force-overwrite  https://drive.google.com/uc?id=14UP0eTwSyrV5HubaR5_z02B0Xf5E0sLH&export=download
wait

opkg install --force-overwrite  https://drive.google.com/uc?id=1BaR2Gy2DGkhFhOXN36gZEuPr7AWf2VLL&export=download
wait

opkg install --force-overwrite  https://drive.google.com/uc?id=1GbTRoiBCBVpM1nWHaQdy1OXoZMlapEnl&export=download
wait

opkg install --force-overwrite  https://drive.google.com/uc?id=1CBTK9_xu1rNrTaBL1JIk4qGNBDViuoHl&export=download
wait
sleep 2;
exit 0








