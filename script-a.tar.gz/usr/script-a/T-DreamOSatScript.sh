opkg remove enigma2-plugin-extensions-DreamOSatScript owait
sleep 2;
opkg install --force-overwrite https://drive.google.com/uc?id=1f6INy7iCRsbFA-4uIpQVQESmC76GlNSq&export=download
wait
sleep 2;
exit 0


