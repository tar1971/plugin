opkg remove enigma2-plugin-extensions-EPGGrabber wait
sleep 2;
wget https://raw.githubusercontent.com/ziko-ZR1/Epg-plugin/master/Download/installer.sh -O - | /bin/sh
wait
sleep 2;
exit 0