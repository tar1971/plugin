opkg install --force-overwrite https://github.com/tarekzoka/oscam-nacam/blob/main/enigma2-plugin-softcams-ncam_V12.7-r0_all.ipk?raw=true
wait
sleep 2;
exit 0











