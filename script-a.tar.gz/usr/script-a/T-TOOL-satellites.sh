
#!/bin/sh
#

wget -O /etc/tuxbox/satellites.xml "https://drive.google.com/uc?id=1t9kkxeco-4CM80wuBIYrL3XxcaJ-qyGr&export=download"
wait
wget -O /etc/enigma2/satellites.xml "https://drive.google.com/uc?id=1t9kkxeco-4CM80wuBIYrL3XxcaJ-qyGr&export=download"

killall -9 enigma2

sleep 2;



