wget http://tunisia-dreambox.info/TSpanel/software_official/installer.sh -O - | /bin/sh




