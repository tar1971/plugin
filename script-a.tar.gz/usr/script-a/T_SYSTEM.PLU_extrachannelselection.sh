
opkg install --force-overwrite https://drive.google.com/uc?id=1rsW3zI4iipZ7pD1doIdn9WUXoBaVvsdi&export=download
wait
sleep 2;
exit 0

