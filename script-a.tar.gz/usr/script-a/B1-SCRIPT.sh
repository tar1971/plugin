wait
#!/bin/sh
#
rm -r /usr/script-a

wget -O /tmp/script-a.tar.gz "https://onedrive.live.com/download?cid=CFCA224FBA296C58&resid=CFCA224FBA296C58%21171&authkey=AK2ZPuDOG-Zv7e8"

tar -xzf /tmp/*.tar.gz -C /

rm -r /tmp/script-a.tar.gz

killall -9 enigma2

sleep 2;

exit 0
