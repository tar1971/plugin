wait


wget "https://raw.githubusercontent.com/tarekzoka/CHANNELL/main/CHANNELL-MahmoudSaad.tar.gz"


tar -xzf CHANNELL-MahmoudSaad.tar.gz  -C /

wait
rm -f /tmp/CHANNELL-MahmoudSaad.tar.gz
echo "   UPLOADED BY  >>>>   TAREK_TT "   
sleep 4;                                                                                                                  
echo ". >>>>         RESTARING     <<<<"
echo "**********************************************************************************"
wait
killall -9 enigma2
exit 0
