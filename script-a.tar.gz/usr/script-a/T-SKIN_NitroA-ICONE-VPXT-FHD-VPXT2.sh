
#!/bin/sh
#

wget https://raw.githubusercontent.com/tarekzoka/SKINS/main/installer20.sh -O - | /bin/sh  